const root = document.getElementById('root');
const newDiv = document.createElement('div');
newDiv.innerText = '🐰';
newDiv.className = 'emoji-lg';
root.appendChild(newDiv);
